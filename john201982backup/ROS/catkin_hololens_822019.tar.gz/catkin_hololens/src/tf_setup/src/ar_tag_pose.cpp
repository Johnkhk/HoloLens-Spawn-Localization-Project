#include <ros/ros.h>
#include <ar_track_alvar_msgs/AlvarMarkers.h>
#include <geometry_msgs/Pose.h>


ros::Publisher *ppub;

void posecallback(const ar_track_alvar_msgs::AlvarMarkersConstPtr& msg)
{
  geometry_msgs::Pose output;
  if (msg->markers.size() > 0)
  {
    output = msg->markers[0].pose.pose;
    ppub->publish(output);
  }
  return;
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "ar_tag_pose");
  ros::NodeHandle nh;
  ros::Publisher pub = nh.advertise<geometry_msgs::Pose>("/ar_tag_pose", 1);
  ppub = &pub;
  ros::Subscriber sub = nh.subscribe("/ar_pose_marker", 1, posecallback);

  ros::spin();

  return 0;
}
