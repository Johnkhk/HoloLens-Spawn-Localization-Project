#include <ros/ros.h>
#include <ros/console.h>
#include <tf/transform_broadcaster.h>

int main(int argc, char** argv){
  ros::init(argc, argv, "tf_broadcaster");
  ros::NodeHandle n;
  tf::Quaternion q;

  ros::Rate r(20);

  tf::TransformBroadcaster broadcaster;

  while(n.ok()){
    
    q.setRPY(0,0,0);
    broadcaster.sendTransform(
      tf::StampedTransform(
        tf::Transform(q, tf::Vector3(0.0, -0.06175, -0.02474)),
        ros::Time::now(),"map", "torso"));

  }
}
